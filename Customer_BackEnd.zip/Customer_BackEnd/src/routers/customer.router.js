const express = require('express');
const {expressx} = require('ca-webutils');
const customerController = require('../controllers/customer.controller');
const paymentController = require('../controllers/payment.controller');

const createRouter = () => {
    const router = express.Router();
    let {routeHandler} = expressx;
    let customerControl = customerController() 
    let paymentControl = paymentController()
 
    router
     .route('/')
     .get(routeHandler(customerControl.getAllCustomer))
     .post(routeHandler(customerControl.addCustomer));

    router
     .route('/:id')
     .get(routeHandler(customerControl.getCustomerById))
     .put(routeHandler(customerControl.updateCustomer))
     .delete(routeHandler(customerControl.deleteCustomer));
    
     router
     .route('/:id/payments')
     .get(routeHandler(paymentControl.getPaymentsByCustomerId))

    return router;
}

module.exports = createRouter;